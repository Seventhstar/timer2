// BROWSER DETECTION
	var matched, browser;
	
	$.uaMatch = function( ua ) {
		ua = ua.toLowerCase();

		var match = /(chrome)[ \/]([\w.]+)/.exec( ua ) ||
			/(webkit)[ \/]([\w.]+)/.exec( ua ) ||
			/(opera)(?:.*version|)[ \/]([\w.]+)/.exec( ua ) ||
			/(msie) ([\w.]+)/.exec( ua ) ||
			ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec( ua ) ||
			[];

		return {
			browser: match[ 1 ] || "",
			version: match[ 2 ] || "0"
		};
	};

	matched = $.uaMatch( navigator.userAgent );
	browser = {};

	if ( matched.browser ) {
		browser[ matched.browser ] = true;
		browser.version = matched.version;
	}

	// Chrome is Webkit, but Webkit is also Safari.
	if ( browser.chrome ) {
		browser.webkit = true;
	} else if ( browser.webkit ) {
		browser.safari = true;
	}

	$.browser = browser;
// BROWSER DETECTION

$(document).ready(function(){

// Datepicker _start
    $.datepicker.regional['ru'] = {
		showOtherMonths: true,
		selectOtherMonths: true,
        monthNames: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'],
        monthNamesShort: ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'],
        dayNames: ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'],
        dayNamesShort: ['вск', 'пнд', 'втр', 'срд', 'чтв', 'птн', 'сбт'],
        dayNamesMin: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
        weekHeader: 'Нед',
        dateFormat: 'dd.mm.yy',
        firstDay: 1,
        isRTL: false,
        showMonthAfterYear: false
    };
    $.datepicker.setDefaults($.datepicker.regional['ru']);

	$(document).on('click', '.datepicker', function (event) {
		var $txt = $(this),
			val = $txt.val(),			
			placeholder = $(this).attr('placeholder'); //if (val!='') 
			
		$(this).datepicker({
			showOn: 'focus',
			dateFormat: 'dd.mm.yy',
			timeFormat:  "HH:mm",
			onClose: function() {},
			beforeShow: function(){
				var offsetTop = $('#ui-datepicker-div').offset().top;
				//if (!val && val!='') {
				//	$txt.val(placeholder);					
				//}
				//alert(offsetTop);
			}
		}).focus();
	});
});